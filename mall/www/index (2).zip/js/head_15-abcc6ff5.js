const a="/www/jpg/name-9e24f9ad.jpg";export{a as default};
