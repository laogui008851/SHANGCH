const e="/www/jpg/name-9e93e827.jpg";export{e as default};
