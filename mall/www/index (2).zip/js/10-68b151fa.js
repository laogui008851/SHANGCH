const e="/www/png/name-eb40a9be.png";export{e as default};
