System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/png/name-d5dbab23.png")}}}));
