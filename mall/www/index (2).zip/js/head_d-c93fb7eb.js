const a="/www/jpg/name-556b5391.jpg";export{a as default};
