const a="/www/png/name-abbd7e16.png";export{a as default};
