const a="/www/png/name-3e40215a.png";export{a as default};
