System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/png/name-61e1a338.png")}}}));
