const e="/www/jpg/name-2d37e556.jpg";export{e as default};
