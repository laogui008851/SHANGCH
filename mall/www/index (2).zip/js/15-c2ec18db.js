const e="/www/png/name-76e71516.png";export{e as default};
