const a="/www/jpg/name-c93f2cb0.jpg";export{a as default};
