const a="/www/png/name-b2bb3866.png";export{a as default};
