System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/jpg/name-2d37e556.jpg")}}}));
