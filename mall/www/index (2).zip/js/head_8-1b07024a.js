const a="/www/jpg/name-68f286f4.jpg";export{a as default};
