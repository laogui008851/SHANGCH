System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/png/name-76e71516.png")}}}));
