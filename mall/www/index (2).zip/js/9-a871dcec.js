const e="/www/png/name-36248e5c.png";export{e as default};
