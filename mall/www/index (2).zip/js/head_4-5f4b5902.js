const a="/www/jpg/name-89910b3d.jpg";export{a as default};
