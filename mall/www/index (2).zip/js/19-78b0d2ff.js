const n="/www/png/name-6f4809d9.png";export{n as default};
