const e="/www/jpg/name-e8142140.jpg";export{e as default};
