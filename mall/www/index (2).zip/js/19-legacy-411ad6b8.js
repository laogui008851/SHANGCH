System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/png/name-6f4809d9.png")}}}));
