const n="/www/png/name-c4f095b9.png";export{n as default};
