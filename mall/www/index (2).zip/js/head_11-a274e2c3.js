const a="/www/jpg/name-70c1ca44.jpg";export{a as default};
