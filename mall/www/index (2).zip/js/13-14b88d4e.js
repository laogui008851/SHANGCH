const n="/www/png/name-fb2f3616.png";export{n as default};
