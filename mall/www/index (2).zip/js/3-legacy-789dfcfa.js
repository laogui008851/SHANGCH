System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/png/name-b2bb3866.png")}}}));
