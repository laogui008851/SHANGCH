System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/jpg/name-9e24f9ad.jpg")}}}));
