const e="/www/png/name-06e7e6f2.png";export{e as default};
