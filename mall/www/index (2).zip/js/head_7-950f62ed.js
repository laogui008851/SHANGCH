const e="/www/jpg/name-6ee36b31.jpg";export{e as default};
