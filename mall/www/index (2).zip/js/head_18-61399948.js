const e="/www/jpg/name-89e55168.jpg";export{e as default};
