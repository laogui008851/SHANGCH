const a="/www/png/name-61e1a338.png";export{a as default};
