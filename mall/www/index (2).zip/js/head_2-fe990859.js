const e="/www/jpg/name-573e8c4e.jpg";export{e as default};
