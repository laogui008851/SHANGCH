const a="/www/png/name-9a6f541c.png";export{a as default};
