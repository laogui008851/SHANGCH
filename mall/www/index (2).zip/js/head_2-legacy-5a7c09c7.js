System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/jpg/name-573e8c4e.jpg")}}}));
