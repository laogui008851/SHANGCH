const c="/www/png/name-e5c455cc.png";export{c as default};
