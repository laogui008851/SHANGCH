const e="/www/png/name-6e79b4d8.png";export{e as default};
