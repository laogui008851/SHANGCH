System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/png/name-36248e5c.png")}}}));
