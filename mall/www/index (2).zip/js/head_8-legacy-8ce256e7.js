System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/jpg/name-68f286f4.jpg")}}}));
