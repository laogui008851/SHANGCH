const a="/www/jpg/name-6475f4b6.jpg";export{a as default};
