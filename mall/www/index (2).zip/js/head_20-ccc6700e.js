const a="/www/jpg/name-30260b0c.jpg";export{a as default};
