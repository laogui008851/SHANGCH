System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/jpg/name-e8142140.jpg")}}}));
