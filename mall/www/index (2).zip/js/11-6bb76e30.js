const n="/www/png/name-219d8586.png";export{n as default};
