const a="/www/jpg/name-ffbf6b16.jpg";export{a as default};
