System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/png/name-3e40215a.png")}}}));
