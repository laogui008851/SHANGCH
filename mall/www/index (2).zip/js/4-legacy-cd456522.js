System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/png/name-e5c455cc.png")}}}));
