const n="/www/png/name-c3062cb0.png";export{n as default};
