const n="/www/png/name-195c213d.png";export{n as default};
