System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/jpg/name-6475f4b6.jpg")}}}));
