const n="/www/png/name-656cd634.png";export{n as default};
