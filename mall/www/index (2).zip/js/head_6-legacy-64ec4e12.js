System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/jpg/name-c93f2cb0.jpg")}}}));
