const n="/www/png/name-b2bb3866.png";export{n as default};
