const a="/www/jpg/name-59d54c27.jpg";export{a as default};
