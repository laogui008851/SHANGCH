const n="/www/png/name-693679bf.png";export{n as default};
