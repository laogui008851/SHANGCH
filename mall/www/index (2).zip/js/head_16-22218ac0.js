const a="/www/jpg/name-06c09aa5.jpg";export{a as default};
