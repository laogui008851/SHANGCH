System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/png/name-195c213d.png")}}}));
