const e="/www/jpg/name-3997d5e5.jpg";export{e as default};
