System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/www/jpg/name-a51c2c82.jpg")}}}));
