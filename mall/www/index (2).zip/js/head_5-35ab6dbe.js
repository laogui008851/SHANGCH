const a="/www/jpg/name-a51c2c82.jpg";export{a as default};
