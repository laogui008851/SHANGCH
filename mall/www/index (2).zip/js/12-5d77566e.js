const a="/www/png/name-d5dbab23.png";export{a as default};
